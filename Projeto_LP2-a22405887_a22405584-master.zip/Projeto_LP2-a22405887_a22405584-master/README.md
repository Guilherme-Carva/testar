![](diagrama.png?raw=true "Diagrama UML")
