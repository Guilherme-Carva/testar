package pt.ulusofona.lp2.greatprogrammingjourney;


public class Crash extends Abismo {

    Crash(int id , String nome){
        super(id , nome);
    }

    @Override
    String mensagem(){
        return "Foi afetado pelo abismo 'Crash'! Volta à primeira casa";
    }
}
