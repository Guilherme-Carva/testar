package pt.ulusofona.lp2.greatprogrammingjourney;


public class FileNotFoundException extends Abismo{

    FileNotFoundException(int id , String nome){
        super(id , nome);
    }

    @Override
    String mensagem(){
        return "Foi afetado pelo abismo 'FileNotFoundException'! Recua 3 casas";
    }
}
