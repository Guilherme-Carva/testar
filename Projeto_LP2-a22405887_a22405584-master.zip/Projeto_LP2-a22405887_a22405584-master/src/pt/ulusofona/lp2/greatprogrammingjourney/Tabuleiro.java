
package pt.ulusofona.lp2.greatprogrammingjourney;


import java.util.HashMap;

public class Tabuleiro {
    int worldSize;
    HashMap<String, String> casas;

    public Tabuleiro(int worldSize){
        this.worldSize = worldSize;
        this.casas = new HashMap<>();

        for(int i = 1; i <= worldSize; i++){
            casas.put(String.valueOf(i), "Normal");
        }

        casas.put("1", "Início");
        casas.put(String.valueOf(worldSize), "Fim");
    }

    public int getWorldSize(){
        return worldSize;
    }

}
