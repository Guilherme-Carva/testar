package pt.ulusofona.lp2.greatprogrammingjourney;


public class Duplicado extends Abismo {

    Duplicado(int id , String nome){
        super(id , nome);
    }

    @Override
    String mensagem(){
        return "Foi afetado pelo abismo 'Duplicated code'! Volta à posição anterior";
    }
}
