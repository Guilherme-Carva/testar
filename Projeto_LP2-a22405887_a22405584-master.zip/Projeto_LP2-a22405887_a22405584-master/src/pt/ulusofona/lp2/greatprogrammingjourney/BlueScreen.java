package pt.ulusofona.lp2.greatprogrammingjourney;


public class BlueScreen extends Abismo {

    BlueScreen(int id , String nome){
        super(id , nome);
    }

    @Override
    String mensagem(){
        return "Foi afetado pelo abismo 'Blue Screen of Death'! Perde o jogo";
    }
}
