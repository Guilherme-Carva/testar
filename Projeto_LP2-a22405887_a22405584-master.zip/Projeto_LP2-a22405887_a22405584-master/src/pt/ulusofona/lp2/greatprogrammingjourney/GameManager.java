package pt.ulusofona.lp2.greatprogrammingjourney;

import javax.swing.*;
import java.util.ArrayList;
import java.util.HashMap;

public class GameManager {
    Jogador jogador;
    ArrayList<Jogador> playersData;
    Tabuleiro tabuleiro;
    int currentPlayerIndex ;
    int turno ;
    int winnerIndex;


    //contrutor
    GameManager() {
        jogador = new Jogador();
        playersData = new ArrayList<>();
        tabuleiro = null;
        currentPlayerIndex = 0;
        turno = 0;
        winnerIndex = -1;
    }

    public boolean verificaPlayerInfoEWorldSize(String[][] playerInfo, int worldSize) {
        if (playerInfo.length < 2 || playerInfo.length > 4) {
            return false;
        } else if (!jogador.verificaJogadores(playerInfo)) {
            return false;
        } else if (worldSize < playerInfo.length * 2) {
            return false;
        } else {
            return true;
        }
    }

    public boolean createInitialBoard(String[][] playerInfo, int worldSize) {
        if (playerInfo.length < 2 || playerInfo.length > 4) {
            return false;
        } else if (!jogador.verificaJogadores(playerInfo)) {
            return false;
        } else if (worldSize < playerInfo.length * 2) {
            return false;
        }

        playersData.clear();
        winnerIndex = -1;
        currentPlayerIndex = 0;
        turno = 0;
        tabuleiro = new Tabuleiro(worldSize);

        playersData = Jogador.criaJogadores(playerInfo);

        // define o jogador inicial (menor ID)
        int menorId = playersData.getFirst().id;
        currentPlayerIndex = 0;

        for (int i = 1; i < playersData.size(); i++) {
            if (playersData.get(i).id < menorId) {
                menorId = playersData.get(i).id;
                currentPlayerIndex = i;
            }
        }

        turno = 1;
        return true;

    }

    public String getImagePng(int nrSquare) {
        if (nrSquare < 1 || nrSquare > tabuleiro.worldSize) {
            return null;
        } else if (nrSquare == tabuleiro.worldSize - 1) {
            return "null";
        }

        if (nrSquare == tabuleiro.worldSize) {
            return "glory.png";
        }

        for (int i = 1; i <= nrSquare; i++) {
            return "null";
        }
        return null;
    }

    public String[] getProgrammerInfo(int id) {

        int guarda = -1;
        for (int pos = 0; pos < playersData.size(); pos++) {
            if (playersData.get(pos).id == id) {
                guarda = pos;
            }
        }
        if (guarda == -1) {
            return null;
        }
        Jogador jogadorInfo = playersData.get(guarda);


        return new String[]{
                String.valueOf(jogadorInfo.id),
                jogadorInfo.nome,
                jogadorInfo.linguagem,
                jogadorInfo.cor,
                jogadorInfo.estado,
                String.valueOf(jogadorInfo.posicao)
        };
    }

    public String getProgrammerInfoAsStr(int id) {
        int guarda = -1;
        for (int pos = 0; pos < playersData.size(); pos++) {
            if (playersData.get(pos).id == id) {
                guarda = pos;
            }
        }
        if (guarda == -1) {
            return null;
        }
        Jogador resultado = new Jogador(playersData.get(guarda).id, playersData.get(guarda).nome, playersData.get(guarda).linguagem, playersData.get(guarda).cor, playersData.get(guarda).estado, playersData.get(guarda).posicao);

        return resultado.toString();
    }

    public String[] getSlotInfo(int position) {
        if (tabuleiro == null || position < 1 || position > tabuleiro.worldSize) {
            return null;
        }

        // Guardar como inteiros para ordenar numericamente
        ArrayList<Integer> idsNum = new ArrayList<>();

        for (Jogador jogadorId : playersData) {
            if (jogadorId.posicao == position) {
                idsNum.add(jogadorId.id);
            }
        }

        if (idsNum.isEmpty()) {
            return new String[]{""};
        }

        java.util.Collections.sort(idsNum);


        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < idsNum.size(); i++) {
            sb.append(idsNum.get(i));
            if (i < idsNum.size() - 1) {
                sb.append(",");
            }
        }

        return new String[]{sb.toString()};
    }

    public int getCurrentPlayerID() {
        int menorId = playersData.get(0).id;
        if (turno == 0) {
            for (int pos = 1; pos < playersData.size(); pos++) {
                if (playersData.get(pos).id < menorId) {
                    menorId = playersData.get(pos).id;
                }
            }
            return menorId;
        }
        return playersData.get(currentPlayerIndex).id;

    }

    public boolean moveCurrentPlayer(int nrSpaces) {
        if (tabuleiro == null) {
            return false;
        }
        if (nrSpaces < 1 || nrSpaces > 6) {
            return false;
        }

        Jogador atual = playersData.get(currentPlayerIndex); // jogador atual
        int currentPosition = atual.posicao;
        int destino = currentPosition + nrSpaces;

        //  (se passar do fim, recua 1)
        if (destino > tabuleiro.worldSize) {
            if (currentPosition > 1) {
                atual.posicao = currentPosition - 1;
            }
        } else {
            atual.posicao = destino;
        }

        currentPlayerIndex = (currentPlayerIndex + 1) % playersData.size();
        turno++;

        return true;
    }

    public boolean gameIsOver() {
        for (int pos = 0; pos < playersData.size(); pos++) {
            if (playersData.get(pos).posicao == tabuleiro.worldSize) {
                winnerIndex = pos;
                for (int m = 0; m < playersData.size() && m != winnerIndex; m++) {
                    playersData.get(m).estado = "Derrotado";
                }

                return true;
            }
        }
        return false;
    }

    public ArrayList<String> getGameResults() {
        ArrayList<String> resultado = new ArrayList<>();
        ArrayList<String[]> restantes = new ArrayList<>();

        if (!gameIsOver()) {
            return resultado; // jogo ainda não acabou
        }
//
        resultado.add("THE GREAT PROGRAMMING JOURNEY");
        resultado.add("");
        resultado.add("NR. DE TURNOS");
        resultado.add(String.valueOf(turno));
        resultado.add("");
        resultado.add("VENCEDOR");
        resultado.add(playersData.get(winnerIndex).nome);
        resultado.add("");
        resultado.add("RESTANTES");


        for (int i = 0; i < playersData.size(); i++) {
            if (i != winnerIndex) {
                String nome = playersData.get(i).nome;
                int posicao = playersData.get(i).posicao;
                restantes.add(new String[]{nome, String.valueOf(posicao)});
            }
        }

        restantes.sort((a, b) -> {
            int posA = Integer.parseInt(a[1]);
            int posB = Integer.parseInt(b[1]);
            if (posA != posB) {
                return Integer.compare(posB, posA);
            } else {
                return a[0].compareToIgnoreCase(b[0]);
            }
        });

        for (String[] jogadorAtual : restantes) {
            resultado.add(jogadorAtual[0] + " " + jogadorAtual[1]);
        }

        return resultado;
    }

    public JPanel getAuthorsPanel() {
        JPanel panel = new JPanel();
        panel.add(new JLabel("Nome: Diogo Oliveira"));
        panel.add(new JLabel("Número: a22405887"));
        return panel;
    }

    public HashMap<String, String> customizeBoard() {
        return new HashMap<>();
    }

    /* Formato abyssesAndTools
    [0] => Tipo: 0 (abismo) ou 1 (ferramenta)
    [1] => ID do subtipo (0-9 para abismos, 0-5 para ferramentas)
    [2] => Posição no tabuleiro (número de casa, de 1 a worldSize)*/

    public boolean verificaTipo(String[][] abyssesAndTools) {
        int i;
        for (i = 0; i < abyssesAndTools.length; i++) {
            int tipo = Integer.parseInt(abyssesAndTools[i][0]);

            if (tipo != 0 && tipo != 1) {
                return false;
            }
        }
        return true;
    }

    public boolean verificaId(String[][] abyssesAndTools) {
        for (int i = 0; i < abyssesAndTools.length; i++) {
            int tipo = Integer.parseInt(abyssesAndTools[i][0]);
            int id = Integer.parseInt(abyssesAndTools[i][1]);

            if (tipo == 0) {
                if (id < 0 || id >= 9) return false;
            } else if (tipo == 1) {
                if (id < 0 || id >= 6) return false;
            } else {
                return false;
            }
        }

        return true;
    }

    public boolean verificaPosiçao(String[][] abyssesAndTools, Tabuleiro tabuleiro) {
        for (int i = 0; i < abyssesAndTools.length; i++) {
            int posicao = Integer.parseInt(abyssesAndTools[i][2]);
            if (posicao > tabuleiro.getWorldSize() || posicao < 1) {
                return false;
            }
        }
        return true;
    }


    public boolean verificaTools(String[][] abyssesAndTools) {
        if (!verificaTipo(abyssesAndTools)) {
            return false;
        } else if (!verificaId(abyssesAndTools)) {
            return false;
        } else if (!verificaPosiçao(abyssesAndTools, tabuleiro)) {
            return false;
        }
        return true;
    }

    public boolean createInitialBoard(String[][] playerInfo, int worldSize, String[][] abyssesAndTools) {

        if (!verificaPlayerInfoEWorldSize(playerInfo, worldSize)) return false;
        if (!verificaTools(abyssesAndTools)) return false;

        playersData.clear();
        winnerIndex = -1;
        currentPlayerIndex = 0;
        turno = 0;

        tabuleiro = new Tabuleiro(worldSize);
        playersData = Jogador.criaJogadores(playerInfo);

        int menorId = playersData.get(0).id;
        currentPlayerIndex = 0;

        for (int i = 1; i < playersData.size(); i++) {
            if (playersData.get(i).id < menorId) {
                menorId = playersData.get(i).id;
                currentPlayerIndex = i;
            }
        }

        for (String[] item : abyssesAndTools) {
            int tipo = Integer.parseInt(item[0]);
            int id = Integer.parseInt(item[1]);
            String pos = item[2];

            String codigo = tipo + ";" + id;
            tabuleiro.casas.put(pos, codigo);
        }

        turno = 1;
        return true;
    }

    public String getProgrammersInfo() {
        StringBuilder string = new StringBuilder();

        for (Jogador j : playersData) {
            if (j.getVida()) {
                if (string.length() > 0) {
                    string.append(" | ");
                }
                string.append(j.nome).append(" : ").append(j.escreveFerramentas());
            }
        }

        return string.toString();
    }

    public String reactToAbyssOrTool(){

    }
}

/* Há 10 tipos de abismos no jogo:

Erro de Sintaxe – Recua 1 casa.
Erro de Lógica – Recua N casas (N = floor(valor_do_dado / 2)).
Exception – Recua 2 casas.
FileNotFoundException – Recua 3 casas.
Crash – Volta à primeira casa.
Código Duplicado – Recua para a casa anterior no histórico.
Efeitos Secundários – Recua para a posição há 2 movimentos atrás.
Blue Screen of Death – Perde o jogo imediatamente.
Ciclo Infinito – Fica preso na casa até outro jogador cair lá.
Segmentation Fault – Ativa se houver 2 ou mais jogadores na mesma casa.

Herança (ID 0): Anula abismos relacionados a herança.
Programação Funcional (ID 1): Anula abismos relacionados a programação funcional.
Testes Unitários (ID 2): Anula abismos relacionados a testes.
Tratamento de Excepções (ID 3): Anula abismos relacionados a erros e exceções.
IDE (ID 4): Anula abismos relacionados a desenvolvimento de software.
Ajuda Do Professor (ID 5): Anula abismos relacionados a dificuldades de aprendizagem.
Cada ferramenta é usada automaticamente ao entrar em abismos correspondentes.
 */