package pt.ulusofona.lp2.greatprogrammingjourney;


public class Ferramenta {

    int id;
    String nome;

    public Ferramenta(int id , String nome){
        this.id = id;
        this.nome = nome;
    }

}
