
package pt.ulusofona.lp2.greatprogrammingjourney;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;

public class Jogador {
    String nome;
    String linguagem ;
    int id;
    String cor;
    int posicao;
    String estado;
    ArrayList<String> ferramentas;
    boolean vivo;

    Jogador(){

    }

    Jogador(int id, String nome,String linguagem, String cor,String estado, int posicao ){
        this.id = id;
        this.nome = nome;
        this.linguagem = linguagem;
        this.cor = cor;
        this.estado = estado;
        this.posicao = posicao;
        this.ferramentas = new ArrayList<>();
        this.vivo = true;

    }

    @Override
    public String toString(){
        return id + " | " + nome + " | " + posicao + " | " + linguagem + " | " + estado;
    }

    public boolean verificaJogadores(String[][] playerInfo){
        HashMap<Integer, Jogador> jogadores = new HashMap<>();
        ArrayList<String> coresValidas = new ArrayList<>();
        coresValidas.add("Purple");
        coresValidas.add("Blue");
        coresValidas.add("Green");
        coresValidas.add("Brown");

        for (String[] strings : playerInfo) {
            try {
                int id = Integer.parseInt(strings[0]);
                String nome = strings[1];

                if (nome == null || nome.trim().isEmpty()) {
                    return false;
                }

                String linguagem = strings[2];
                String cor = strings[3];
                int posicao = 0;
                String estado = "Em Jogo";

                // Verifica se o id é negativo ou já existe
                if (id <= 0 || jogadores.containsKey(id)){
                    return false;
                }

                if (nome.isEmpty()) {
                    return false;
                }
                if (!coresValidas.contains(cor)) {
                    return false;
                }

                // Adiciona o jogador ao mapa (id → linha inteira)
                jogadores.put(id, new Jogador(id, nome, linguagem, cor, estado, posicao));

            } catch (NumberFormatException e) {
                return false; // se não for número
            }
        }

        // Se chegou aqui, todos os IDs são válidos e únicos
        return true;
    }

    public static ArrayList<Jogador> criaJogadores(String[][] playerInfo){
        ArrayList<Jogador> lista = new ArrayList<>();


        for (String[] info : playerInfo) {
            int id = Integer.parseInt(info[0]);
            String nome = info[1];
            String linguagem = info[2];
            String[] linguagens = linguagem.split(";");  // separa pelo ";"
            for (int i = 0; i < linguagens.length; i++) {
                linguagens[i] = linguagens[i].trim();    // tira espaços em branco
            }
            Arrays.sort(linguagens);                     // ordena em ordem alfabética
            linguagem = String.join("; ", linguagens);   // junta novamente com "; "
            String cor = info[3];
            lista.add(new Jogador(id, nome, linguagem, cor, "Em Jogo", 1 ));
        }
        return lista;
    }

    boolean getVida(){
        return vivo;
    }

    void morre(){
        vivo = false;
    }

    public String escreveFerramentas() {
        if (ferramentas == null || ferramentas.isEmpty()) {
            return "No tools";
        }
        return String.join(";", ferramentas);
    }


    public String toolsToString(){
        return   nome + " : " + escreveFerramentas();
   }
}
