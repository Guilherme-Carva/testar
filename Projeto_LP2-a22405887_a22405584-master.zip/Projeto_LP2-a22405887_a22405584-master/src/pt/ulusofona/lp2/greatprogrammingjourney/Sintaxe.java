package pt.ulusofona.lp2.greatprogrammingjourney;


public  class Sintaxe extends Abismo {

     Sintaxe(int id , String nome){
      super(id , nome) ;
    }

    @Override
     String mensagem(){
return "Caiu num erro de sintaxe! Recua 1 casa";
    }
}
