package pt.ulusofona.lp2.greatprogrammingjourney;

import org.junit.jupiter.api.*;
import static org.junit.jupiter.api.Assertions.*;
import static org.junit.jupiter.api.Assertions.assertNull;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;

class TestGameManager {

    private GameManager gameManager;

    @BeforeEach
    void setUp() {
        gameManager = new GameManager();
    }

    @Nested
    @DisplayName("Testes de Validação de IDs")
    class TestValidacaoId {

        @Test
        @DisplayName("Deve aceitar IDs únicos e positivos")
        void testVerificaIdValido() {
            String[][] playerInfo = {
                    {"1", "Alice", "Java", "Blue"},
                    {"2", "Bob", "Python", "Green"}
            };
            assertTrue(gameManager.jogador.verificaJogadores(playerInfo));
        }

        @Test
        @DisplayName("Deve rejeitar IDs duplicados")
        void testVerificaIdDuplicado() {
            String[][] playerInfo = {
                    {"1", "Alice", "Java", "Blue"},
                    {"1", "Bob", "Python", "Green"}
            };
            assertFalse(gameManager.jogador.verificaJogadores(playerInfo));
        }

        @Test
        @DisplayName("Deve rejeitar IDs negativos")
        void testVerificaIdNegativo() {
            String[][] playerInfo = {
                    {"-1", "Alice", "Java", "Blue"},
                    {"2", "Bob", "Python", "Green"}
            };
            assertFalse(gameManager.jogador.verificaJogadores(playerInfo));
        }
    }

    @Nested
    @DisplayName("Testes de Validação de Nomes")
    class TestValidacaoNome {

        @Test
        @DisplayName("Deve aceitar nomes válidos")
        void testVerificaNomeValido() {
            String[][] playerInfo = {
                    {"1", "Alice", "Java", "Blue"},
                    {"2", "Bob", "Python", "Green"}
            };
            assertTrue(gameManager.jogador.verificaJogadores(playerInfo));
        }

        @Test
        @DisplayName("Deve rejeitar nome nulo")
        void testVerificaNomeNulo() {
            String[][] playerInfo = {
                    {"1", null, "Java", "Blue"},
                    {"2", "Bob", "Python", "Green"}
            };
            assertFalse(gameManager.jogador.verificaJogadores(playerInfo));
        }

        @Test
        @DisplayName("Deve rejeitar nome vazio")
        void testVerificaNomeVazio() {
            String[][] playerInfo = {
                    {"1", "", "Java", "Blue"},
                    {"2", "Bob", "Python", "Green"}
            };
            assertFalse(gameManager.jogador.verificaJogadores(playerInfo));
        }
    }

    @Nested
    @DisplayName("Testes de Validação de Cores")
    class TestValidacaoCor {

        @Test
        @DisplayName("Deve aceitar cores válidas")
        void testVerificaCorValida() {
            String[][] playerInfo = {
                    {"1", "Alice", "Java", "Purple"},
                    {"2", "Bob", "Python", "Blue"},
                    {"3", "Charlie", "C++", "Green"},
                    {"4", "Diana", "JavaScript", "Brown"}
            };
            assertTrue(gameManager.jogador.verificaJogadores(playerInfo));
        }

        @Test
        @DisplayName("Deve rejeitar cor inválida")
        void testVerificaCorInvalida() {
            String[][] playerInfo = {
                    {"1", "Alice", "Java", "Red"},
                    {"2", "Bob", "Python", "Blue"}
            };
            assertFalse(gameManager.jogador.verificaJogadores(playerInfo));
        }
    }

    @Nested
    @DisplayName("Testes de Criação do Tabuleiro")
    class TestCriacaoTabuleiro {

        @Test
        @DisplayName("Deve criar tabuleiro com dados válidos")
        void testCreateInitialBoardValido() {
            String[][] playerInfo = {
                    {"1", "Alice", "Java", "Blue"},
                    {"2", "Bob", "Python", "Green"}
            };
            assertTrue(gameManager.createInitialBoard(playerInfo, 10));
            assertNotNull(gameManager.tabuleiro);
            assertEquals(10, gameManager.tabuleiro.worldSize);
        }

        @Test
        @DisplayName("Deve rejeitar menos de 2 jogadores")
        void testCreateInitialBoardMenosDe2Jogadores() {
            String[][] playerInfo = {
                    {"1", "Alice", "Java", "Blue"}
            };
            assertFalse(gameManager.createInitialBoard(playerInfo, 10));
        }

        @Test
        @DisplayName("Deve rejeitar mais de 4 jogadores")
        void testCreateInitialBoardMaisDe4Jogadores() {
            String[][] playerInfo = {
                    {"1", "Alice", "Java", "Blue"},
                    {"2", "Bob", "Python", "Green"},
                    {"3", "Charlie", "C++", "Purple"},
                    {"4", "Diana", "JavaScript", "Brown"},
                    {"5", "Eve", "Ruby", "Blue"}
            };
            assertFalse(gameManager.createInitialBoard(playerInfo, 10));
        }

        @Test
        @DisplayName("Deve rejeitar worldSize menor que 2x número de jogadores")
        void testCreateInitialBoardWorldSizePequeno() {
            String[][] playerInfo = {
                    {"1", "Alice", "Java", "Blue"},
                    {"2", "Bob", "Python", "Green"}
            };
            assertFalse(gameManager.createInitialBoard(playerInfo, 3));
        }

        @Test
        @DisplayName("Deve ordenar linguagens alfabeticamente")
        void testOrdenacaoLinguagens() {
            String[][] playerInfo = {
                    {"1", "Alice", "Python; Java; C++", "Blue"},
                    {"2", "Bob", "Ruby", "Green"}
            };
            gameManager.createInitialBoard(playerInfo, 10);
            assertEquals("C++; Java; Python", gameManager.playersData.get(0).linguagem);
        }

        @Test
        @DisplayName("Deve definir jogador com menor ID como atual")
        void testJogadorInicialMenorId() {
            String[][] playerInfo = {
                    {"5", "Alice", "Java", "Blue"},
                    {"2", "Bob", "Python", "Green"},
                    {"8", "Charlie", "C++", "Purple"}
            };
            gameManager.createInitialBoard(playerInfo, 10);
            assertEquals(2, gameManager.getCurrentPlayerID());
        }

        @Test
        @DisplayName("Deve inicializar turno em 1")
        void testTurnoInicial() {
            String[][] playerInfo = {
                    {"1", "Alice", "Java", "Blue"},
                    {"2", "Bob", "Python", "Green"}
            };
            gameManager.createInitialBoard(playerInfo, 10);
            assertEquals(1, gameManager.turno);
        }
    }

    @Nested
    @DisplayName("Testes de Informações de Jogador")
    class TestInformacoesJogador {

        @BeforeEach
        void setupJogo() {
            String[][] playerInfo = {
                    {"1", "Alice", "Java", "Blue"},
                    {"2", "Bob", "Python", "Green"}
            };
            gameManager.createInitialBoard(playerInfo, 10);
        }

        @Test
        @DisplayName("Deve retornar informações de jogador válido")
        void testGetProgrammerInfoValido() {
            String[] info = gameManager.getProgrammerInfo(1);
            assertNotNull(info);
            assertEquals(6, info.length);
            assertEquals("1", info[0]);
            assertEquals("Alice", info[1]);
            assertEquals("Java", info[2]);
            assertEquals("Blue", info[3]);
        }

        @Test
        @DisplayName("Deve retornar null para ID inexistente")
        void testGetProgrammerInfoInexistente() {
            String[] info = gameManager.getProgrammerInfo(999);
            assertNull(info);
        }

        @Test
        @DisplayName("Deve retornar string formatada de jogador")
        void testGetProgrammerInfoAsStr() {
            String info = gameManager.getProgrammerInfoAsStr(1);
            assertNotNull(info);
            assertTrue(info.contains("Alice"));
            assertTrue(info.contains("Java"));
        }

        @Test
        @DisplayName("Deve retornar null para string de ID inexistente")
        void testGetProgrammerInfoAsStrInexistente() {
            String info = gameManager.getProgrammerInfoAsStr(999);
            assertNull(info);
        }
    }

    @Nested
    @DisplayName("Testes de Informações de Posição")
    class TestInformacoesSlot {

        @BeforeEach
        void setupJogo() {
            String[][] playerInfo = {
                    {"1", "Alice", "Java", "Blue"},
                    {"2", "Bob", "Python", "Green"}
            };
            gameManager.createInitialBoard(playerInfo, 10);
        }

        @Test
        @DisplayName("Deve retornar IDs de jogadores na posição inicial")
        void testGetSlotInfoPosicaoInicial() {
            String[] info = gameManager.getSlotInfo(1);
            assertNotNull(info);
            assertTrue(info[0].contains("1"));
            assertTrue(info[0].contains("2"));
        }

        @Test
        @DisplayName("Deve retornar array vazio para posição sem jogadores")
        void testGetSlotInfoPosicaoVazia() {
            String[] info = gameManager.getSlotInfo(5);
            assertNotNull(info);
            assertEquals(1, info.length);
            assertEquals("", info[0]);
        }

        @Test
        @DisplayName("Deve retornar null para posição inválida")
        void testGetSlotInfoPosicaoInvalida() {
            String[] info = gameManager.getSlotInfo(20);
            assertNull(info);
        }

        @Test
        @DisplayName("Deve retornar null para posição menor que 1")
        void testGetSlotInfoPosicaoMenorQue1() {
            String[] info = gameManager.getSlotInfo(0);
            assertNull(info);
        }
    }

    @Nested
    @DisplayName("Testes de Movimento de Jogadores")
    class TestMovimentoJogador {

        @BeforeEach
        void setupJogo() {
            String[][] playerInfo = {
                    {"1", "Alice", "Java", "Blue"},
                    {"2", "Bob", "Python", "Green"}
            };
            gameManager.createInitialBoard(playerInfo, 10);
        }

        @Test
        @DisplayName("Deve mover jogador com número válido de casas")
        void testMoveCurrentPlayerValido() {
            String[][] playerInfo = {
                    {"1", "Alice", "Java; C++", "Blue"},
                    {"2", "Bob", "Python", "Green"}
            };
            gameManager.createInitialBoard(playerInfo, 10);

            // Posição inicial deve ser 0
            int posicaoInicial = gameManager.playersData.get(0).posicao;

            // Move o jogador 3 casas
            boolean resultado = gameManager.moveCurrentPlayer(3);

            // O movimento deve ser válido
            assertTrue(resultado);

            // Posição final deve ser inicial + 3
            assertEquals(posicaoInicial + 3, gameManager.playersData.get(0).posicao);
        }

        @Test
        @DisplayName("Deve rejeitar movimento menor que 1")
        void testMoveCurrentPlayerMenorQue1() {
            assertFalse(gameManager.moveCurrentPlayer(0));
        }

        @Test
        @DisplayName("Deve rejeitar movimento maior que 6")
        void testMoveCurrentPlayerMaiorQue6() {
            assertFalse(gameManager.moveCurrentPlayer(7));
        }

        @Test
        @DisplayName("Deve retroceder se ultrapassar o fim do tabuleiro")
        void testMoveCurrentPlayerUltrapassaFim() {
            String[][] playerInfo = {
                    {"1", "Alice", "Java; C++", "Blue"},
                    {"2", "Bob", "Python", "Green"}
            };
            gameManager.createInitialBoard(playerInfo, 10);

            // Coloca o jogador na posição 9 (perto do fim)
            gameManager.playersData.get(0).posicao = 9;

            // Move 3 casas (9 + 3 = 12 > 10)
            gameManager.moveCurrentPlayer(3);

            // Espera-se que recue uma casa (posição 8)
            assertEquals(8, gameManager.playersData.get(0).posicao);
        }

        @Test
        @DisplayName("Deve alternar entre jogadores")
        void testAlternanciaJogadores() {
            int primeiroJogador = gameManager.getCurrentPlayerID();
            gameManager.moveCurrentPlayer(1);
            int segundoJogador = gameManager.getCurrentPlayerID();
            assertNotEquals(primeiroJogador, segundoJogador);
        }

        @Test
        @DisplayName("Deve incrementar turno após movimento")
        void testIncrementoTurno() {
            int turnoInicial = gameManager.turno;
            gameManager.moveCurrentPlayer(3);
            assertEquals(turnoInicial + 1, gameManager.turno);
        }
    }

    @Nested
    @DisplayName("Testes de Fim de Jogo")
    class TestFimJogo {

        @BeforeEach
        void setupJogo() {
            String[][] playerInfo = {
                    {"1", "Alice", "Java", "Blue"},
                    {"2", "Bob", "Python", "Green"}
            };
            gameManager.createInitialBoard(playerInfo, 10);
        }

        @Test
        @DisplayName("Jogo não deve terminar no início")
        void testGameIsOverInicio() {
            assertFalse(gameManager.gameIsOver());
        }

        @Test
        @DisplayName("Jogo deve terminar quando jogador alcança o fim")
        void testGameIsOverVencedor() {
            gameManager.playersData.get(0).posicao = Integer.parseInt("10");
            assertTrue(gameManager.gameIsOver());
        }

        @Test
        @DisplayName("Deve retornar lista vazia se jogo não terminou")
        void testGetGameResultsJogoNaoTerminado() {
            ArrayList<String> results = gameManager.getGameResults();
            assertTrue(results.isEmpty());
        }

        @Test
        @DisplayName("Deve retornar resultados formatados quando jogo termina")
        void testGetGameResultsJogoTerminado() {
            gameManager.playersData.get(0).posicao = Integer.parseInt("10");
            gameManager.turno = 15;
            ArrayList<String> results = gameManager.getGameResults();

            assertFalse(results.isEmpty());
            assertTrue(results.contains("THE GREAT PROGRAMMING JOURNEY"));
            assertTrue(results.contains("15"));
            assertTrue(results.contains("Alice"));
        }

        @Test
        @DisplayName("Deve ordenar jogadores restantes por posição decrescente")
        void testGetGameResultsOrdenacao() {
            gameManager.playersData.get(0).posicao = Integer.parseInt("10"); // Alice vence
            gameManager.playersData.get(1).posicao = Integer.parseInt("7");  // Bob em 2º

            String[][] maisJogadores = {
                    {"1", "Alice", "Java", "Blue"},
                    {"2", "Bob", "Python", "Green"},
                    {"3", "Charlie", "C++", "Purple"}
            };
            gameManager.createInitialBoard(maisJogadores, 10);
            gameManager.playersData.get(0).posicao = Integer.parseInt("10"); // Alice vence
            gameManager.playersData.get(1).posicao = Integer.parseInt("7");  // Bob
            gameManager.playersData.get(2).posicao = Integer.parseInt("5");  // Charlie

            ArrayList<String> results = gameManager.getGameResults();
            int bobIndex = -1;
            int charlieIndex = -1;

            for (int i = 0; i < results.size(); i++) {
                if (results.get(i).contains("Bob")) bobIndex = i;
                if (results.get(i).contains("Charlie")) charlieIndex = i;
            }

            assertTrue(bobIndex < charlieIndex);
        }
    }

    @Nested
    @DisplayName("Testes de Customização do Tabuleiro")
    class TestCustomizacaoTabuleiro {

        @Test
        @DisplayName("Deve retornar HashMap de casas quando tabuleiro existe")
        void testCustomizeBoardComTabuleiro() {
            String[][] playerInfo = {
                    {"1", "Alice", "Java", "Blue"},
                    {"2", "Bob", "Python", "Green"}
            };
            gameManager.createInitialBoard(playerInfo, 10);

            HashMap<String, String> casas = gameManager.customizeBoard();
            assertNotNull(casas);
            assertEquals("Início", casas.get("1"));
            assertEquals("Fim", casas.get("10"));
        }
    }

    @Nested
    @DisplayName("Testes de Imagem PNG")
    class TestImagemPng {

        @BeforeEach
        void setupJogo() {
            String[][] playerInfo = {
                    {"1", "Alice", "Java", "Blue"},
                    {"2", "Bob", "Python", "Green"}
            };
            gameManager.createInitialBoard(playerInfo, 10);
        }

        @Test
        @DisplayName("Deve retornar null para posição inválida menor que 1")
        void testGetImagePngInvalidaMenor() {
            assertNull(gameManager.getImagePng(0));
        }

        @Test
        @DisplayName("Deve retornar null para posição inválida maior que worldSize")
        void testGetImagePngInvalidaMaior() {
            assertNull(gameManager.getImagePng(15));
        }

        @Test
        @DisplayName("Deve retornar 'null' para posições específicas")
        void testGetImagePngPosicoesEspecificas() {
            assertEquals("null", gameManager.getImagePng(1));
            assertEquals("null", gameManager.getImagePng(2));
            assertEquals("null", gameManager.getImagePng(3));
        }
        @Test
        @DisplayName("Deve mostrar corretamente o conteúdo retornado por getSlotInfo")
        void testGetSlotInfoDebug() {
            String[][] playerInfo = {
                    {"1", "Alice", "Java", "Blue"},
                    {"2", "Bob", "Python", "Green"},
                    {"3", "Charlie", "C++", "Purple"}
            };

            // Cria o tabuleiro e os jogadores
            gameManager.createInitialBoard(playerInfo, 10);

            // Verifica a posição inicial (todos devem estar na posição 1)
            String[] slot1 = gameManager.getSlotInfo(1);

            System.out.println("Resultado para posição 1:");
            System.out.println("Tamanho: " + slot1.length);
            for (int i = 0; i < slot1.length; i++) {
                System.out.println("slot1[" + i + "] = \"" + slot1[i] + "\"");
            }

            // Deve conter todos os IDs ("1,2,3") na posição [0]
            assertNotNull(slot1);
            assertTrue(slot1[0].contains("1"));
            assertTrue(slot1[0].contains("2"));
            assertTrue(slot1[0].contains("3"));
        }
    }
    @Test
    @DisplayName("Mover três jogadores em sequência e verificar posições com getSlotInfo()")
    void testMoveThreePlayersAndGetSlotInfo_ComPrints() {
        System.out.println("===== INÍCIO DO TESTE: MOVER 3 JOGADORES =====");

        // --- Criação do jogo ---
        String[][] playerInfo = {
                {"1", "Alice", "Java; C++", "Blue"},
                {"2", "Bob", "Python", "Green"},
                {"3", "Charlie", "C#", "Purple"}
        };

        assertTrue(gameManager.createInitialBoard(playerInfo, 10), "O tabuleiro deve ser criado com sucesso.");

        System.out.println("Tabuleiro criado com tamanho 10 e " + gameManager.playersData.size() + " jogadores.");

        for (Jogador j : gameManager.playersData) {
            System.out.printf("Jogador %s (%s) começa na posição %d.%n", j.id, j.nome, j.posicao);
        }

        // --- Turno 1: Alice ---
        System.out.println("\n[Turno 1] Alice move 3 casas...");
        gameManager.moveCurrentPlayer(3);
        System.out.printf("Nova posição de Alice: %d%n", gameManager.playersData.get(0).posicao);
        assertEquals(4, gameManager.playersData.get(0).posicao);

        // --- Turno 2: Bob ---
        System.out.println("\n[Turno 2] Bob move 5 casas...");
        gameManager.moveCurrentPlayer(5);
        System.out.printf("Nova posição de Bob: %d%n", gameManager.playersData.get(1).posicao);
        assertEquals(6, gameManager.playersData.get(1).posicao);

        // --- Turno 3: Charlie ---
        System.out.println("\n[Turno 3] Charlie move 6 casas...");
        gameManager.moveCurrentPlayer(5);
        System.out.printf("Nova posição de Charlie: %d%n", gameManager.playersData.get(2).posicao);
        assertEquals(6, gameManager.playersData.get(2).posicao);

        // --- Estado geral do tabuleiro ---
        System.out.println("\n===== ESTADO DO TABULEIRO =====");
        for (int i = 1; i <= gameManager.tabuleiro.worldSize; i++) {
            String[] info = gameManager.getSlotInfo(i);
            System.out.printf("Casa %d → %s%n", i, Arrays.toString(info));
        }

        // --- Jogadores na mesma casa ---
        System.out.println("\nColocando Alice e Bob juntos na posição 5...");
        gameManager.playersData.get(0).posicao = 5;
        gameManager.playersData.get(1).posicao = 5;
        String[] slot5 = gameManager.getSlotInfo(5);
        System.out.printf("Casa 5 agora contém: %s%n", Arrays.toString(slot5));
        assertArrayEquals(new String[]{"1,2"}, slot5);

        // --- Teste de posição inválida ---
        System.out.println("\nTestando posição inválida (fora do tabuleiro)...");
        String[] invalid = gameManager.getSlotInfo(11);
        System.out.println("Resultado para casa 11: " + (invalid == null ? "null" : Arrays.toString(invalid)));
        assertNull(invalid);

        System.out.println("\n===== FIM DO TESTE =====");
    }

    @Test
    @DisplayName("Deve mover jogador corretamente e alternar turno")
    void testMoveAlternanciaBasica() {
        String[][] playerInfo = {
                {"1", "Alice", "Java", "Blue"},
                {"2", "Bob", "Python", "Green"},
                {"3", "Charlie", "C#", "Purple"}
        };
        gameManager.createInitialBoard(playerInfo, 10);
        int turnoInicial = gameManager.turno;
        int jogadorInicial = gameManager.getCurrentPlayerID();
        System.out.println("\n--- Teste: Movimento básico ---");
        System.out.println("Jogador atual: " + jogadorInicial);

        boolean moveu = gameManager.moveCurrentPlayer(3);
        System.out.println("Moveu 3 casas? " + moveu);
        System.out.println("Turno atual: " + gameManager.turno);
        System.out.println("Novo jogador atual: " + gameManager.getCurrentPlayerID());

        assertTrue(moveu);
        assertEquals(turnoInicial + 1, gameManager.turno);
        assertNotEquals(jogadorInicial, gameManager.getCurrentPlayerID());

        Jogador j = gameManager.playersData.stream()
                .filter(p -> p.id == jogadorInicial)
                .findFirst()
                .orElse(null);
        assertNotNull(j);
        System.out.println("Nova posição do jogador inicial (" + j.id + "): " + j.posicao);
        assertEquals(4, j.posicao);
    }

    @Test
    @DisplayName("Deve rejeitar movimento menor que 1 e maior que 6")
    void testLimitesDeMovimento() {
        System.out.println("\n--- Teste: Limites de movimento ---");
        System.out.println("Move 0: " + gameManager.moveCurrentPlayer(0));
        System.out.println("Move 7: " + gameManager.moveCurrentPlayer(7));
        assertFalse(gameManager.moveCurrentPlayer(0));
        assertFalse(gameManager.moveCurrentPlayer(7));
    }

    @Test
    @DisplayName("Deve recuar uma casa se ultrapassar o fim do tabuleiro")
    void testUltrapassaFimRetrocede() {
        String[][] playerInfo = {
                {"1", "Alice", "Java", "Blue"},
                {"2", "Bob", "Python", "Green"},
                {"3", "Charlie", "C#", "Purple"}
        };
        gameManager.createInitialBoard(playerInfo, 10);
        System.out.println("\n--- Teste: Retrocesso ao ultrapassar fim ---");
        Jogador atual = gameManager.playersData.get(0);
        atual.posicao = 9;
        System.out.println("Posição inicial: " + atual.posicao);
        boolean moveu = gameManager.moveCurrentPlayer(3);
        System.out.println("Moveu 3 casas (9 + 3 > 10)? " + moveu);
        System.out.println("Nova posição: " + atual.posicao);
        assertTrue(moveu);
        assertEquals(8, atual.posicao);
    }

    @Test
    @DisplayName("Deve alternar corretamente entre jogadores e voltar ao primeiro")
    void testAlternanciaCircular() {
        String[][] playerInfo = {
                {"1", "Alice", "Java", "Blue"},
                {"2", "Bob", "Python", "Green"},
                {"3", "Charlie", "C#", "Purple"}
        };
        gameManager.createInitialBoard(playerInfo, 10);
        System.out.println("\n--- Teste: Alternância circular ---");
        int total = gameManager.playersData.size();
        int primeiro = gameManager.getCurrentPlayerID();
        System.out.println("Primeiro jogador: " + primeiro);

        for (int i = 0; i < total; i++) {
            boolean moveu = gameManager.moveCurrentPlayer(1);
            System.out.printf("Jogada %d → moveu=%s | jogador atual=%d | turno=%d%n",
                    i + 1, moveu, gameManager.getCurrentPlayerID(), gameManager.turno);
        }

        int depoisDeVoltar = gameManager.getCurrentPlayerID();
        System.out.println("Jogador após " + total + " jogadas: " + depoisDeVoltar);
        assertEquals(primeiro, depoisDeVoltar);
    }

    @Test
    @DisplayName("Reiniciar jogo (createInitialBoard duas vezes) — simples e direto")
    void testRestartGame_Simples() {
        // ---------- 1ª inicialização ----------
        String[][] run1 = {
                {"5", "Ana", "Java", "Blue"},
                {"2", "Bruno", "Python", "Green"},
                {"9", "Carlota", "C#", "Purple"}
        };
        assertTrue(gameManager.createInitialBoard(run1, 10));

        // Força posições diferentes para simular jogo em andamento
        gameManager.playersData.get(0).posicao = 7; // id=5
        gameManager.playersData.get(1).posicao = 4; // id=2
        gameManager.playersData.get(2).posicao = 3; // id=9

        // Sanidade: estado antigo não está na posição 1
        assertArrayEquals(new String[]{""}, gameManager.getSlotInfo(1));

        // ---------- 2ª inicialização (REINÍCIO) ----------
        String[][] run2 = {
                {"1", "Alice",  "Java",   "Blue"},
                {"3", "Bob",    "Python", "Green"},
                {"4", "Cris",   "C#",     "Purple"},
                {"2", "Diana",  "Ruby",   "Brown"}
        };
        assertTrue(gameManager.createInitialBoard(run2, 12));

        // Verifica que o tabuleiro foi recriado e o estado reinicializado
        assertNotNull(gameManager.tabuleiro);
        assertEquals(12, gameManager.tabuleiro.worldSize);
        assertEquals(1, gameManager.turno);               // turno reiniciado
        assertEquals(1, gameManager.getCurrentPlayerID()); // menor ID é o atual

        // Todos os novos jogadores devem estar na casa 1
        String[] slot1 = gameManager.getSlotInfo(1);
        assertNotNull(slot1);
        assertEquals(1, slot1.length);

        // Compara de forma ordem-agnóstica
        String obtidoOrdenado = Arrays.stream(slot1[0].split(","))
                .sorted().collect(java.util.stream.Collectors.joining(","));
        assertEquals("1,2,3,4", obtidoOrdenado);

        // As restantes casas devem estar vazias
        for (int casa = 2; casa <= gameManager.tabuleiro.worldSize; casa++) {
            String[] info = gameManager.getSlotInfo(casa);
            assertNotNull(info);
            assertEquals(1, info.length);
            assertEquals("", info[0], "Casa " + casa + " deve estar vazia após restart");
        }

        // Confirma que não sobraram IDs antigos (5 ou 9) em nenhuma casa
        for (int casa = 1; casa <= gameManager.tabuleiro.worldSize; casa++) {
            String[] info = gameManager.getSlotInfo(casa);
            if (info != null && info.length == 1 && !info[0].isEmpty()) {
                for (String idStr : info[0].split(",")) {
                    assertNotEquals("5", idStr, "Id antigo 5 não deve existir após restart");
                    assertNotEquals("9", idStr, "Id antigo 9 não deve existir após restart");
                }
            }
        }
    }


    @Test
    @DisplayName("getSlotInfo: valida quem está na casa 6 (isolado)")
    void testGetSlotInfoIsolado() {
        String[][] info = {
                {"5","Ana","Java","Blue"},
                {"9","Bruno","Python","Green"}
        };
        assertTrue(gameManager.createInitialBoard(info, 10));

        // limpa e define posições explicitamente
        for (Jogador j : gameManager.playersData) j.posicao = 1;
        // põe só o ID 5 na casa 6
        for (Jogador j : gameManager.playersData) {
            if (j.id == 5) j.posicao = 6;
            if (j.id == 9) j.posicao = 3;
        }

        String[] slot6 = gameManager.getSlotInfo(6);
        System.out.println("slot6 = " + java.util.Arrays.toString(slot6));
        assertNotNull(slot6);
        assertEquals(1, slot6.length);
        assertArrayEquals(new String[]{"5"}, slot6);
    }





}