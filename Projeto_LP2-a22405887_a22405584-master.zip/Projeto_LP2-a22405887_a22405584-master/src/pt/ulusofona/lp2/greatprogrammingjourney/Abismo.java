package pt.ulusofona.lp2.greatprogrammingjourney;


public abstract class Abismo {

    String nome;
    int id;

    public Abismo(int id , String nome ){

        this.id = id;

        this.nome = nome;

    }

    abstract String mensagem();
}
