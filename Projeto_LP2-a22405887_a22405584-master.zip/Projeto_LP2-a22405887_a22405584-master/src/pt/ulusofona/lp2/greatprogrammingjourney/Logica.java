package pt.ulusofona.lp2.greatprogrammingjourney;


public class Logica extends Abismo {

    int n;

    Logica(int id , String nome){
        super(id , nome);
    }

    @Override
    String mensagem(){
        return "Caiu num erro de lógica! Recua N casas";
    }
}
