package pt.ulusofona.lp2.greatprogrammingjourney;


public class Exception extends Abismo{

    Exception(int id , String nome){
            super(id , nome);
    }

    @Override
    String mensagem(){
        return "O abismo 'Exception' está ativo! Recua 2 casas";
    }
}
