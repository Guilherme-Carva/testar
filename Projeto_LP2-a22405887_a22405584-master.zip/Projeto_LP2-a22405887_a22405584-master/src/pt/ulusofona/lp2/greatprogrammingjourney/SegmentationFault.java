package pt.ulusofona.lp2.greatprogrammingjourney;


public class SegmentationFault extends Abismo {

    SegmentationFault(int id , String nome){
        super(id , nome);
    }

    @Override
    String mensagem(){
        return "Foi afetado pelo abismo 'Segmentation Fault'! Todos na casa recuam 3 casas";
    }
}
