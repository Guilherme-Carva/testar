package pt.ulusofona.lp2.greatprogrammingjourney;


public class EfeitosSecundarios extends Abismo {

    EfeitosSecundarios(int id , String nome ){
        super (id , nome);
    }

    @Override
    String mensagem(){
        return "Foi afetado pelo abismo 'Secondary Effects'! Volta à posição de 2 movimentos atrás";
    }
}
